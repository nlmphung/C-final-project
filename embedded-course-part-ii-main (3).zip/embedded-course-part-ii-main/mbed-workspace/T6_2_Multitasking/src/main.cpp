/* mbed Microcontroller Library
 * Copyright (c) 2019 ARM Limited
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 In this example, we are going to create two tasks with different priorities

Task 1: It will have Normal Priority
    It will turn on LED1 when Button 1 is pressed, and turn it off when Button 1 is released 

Task 2: It will have AboveNormal Priority 
    It will turn on LED2 when Button 1 is pressed, and turn it off when Button 1 is released 

Expected behavior: Task 2 always indicates the button state earlier than Task 1, since it
has precedence (higher priority)

 */

#include "mbed.h"
#include <iostream>

#include "nrf52832_app_protect.h"
// the following is just a placeholder. You may remove it if you find it fit.
//---------------BEGIN PLACE HOLDER-------------------------/
// Blinking rate in milliseconds
#define BLINKING_RATE     500ms
//---------------END PLACE HOLDER-------------------------/

EventFlags flags;

DigitalOut button(BUTTON1);
InterruptIn button_interrupt(BUTTON1, PullUp);

Thread task1(osPriorityNormal);
Thread task2(osPriorityAboveNormal);

void task1_proc(){
    DigitalOut led(LED1);
    // turn off the LED
    led.write(1);
    while(true) {
        flags.wait_any(1);
        led.write(!led);
        std::cout << "Button state from task 1: " << button.read() << std::endl;
        ThisThread::sleep_for(BLINKING_RATE);
    }
}

void task2_proc(){
    DigitalOut led(LED2);
    // Turn off the LED
    led.write(1);
    while (true) {
        flags.wait_any(2);
        led.write(!led);
        std::cout << "Button state from task 2: " << button.read() << std::endl;
        ThisThread::sleep_for(BLINKING_RATE);
    }
}

void button_isr() {
    flags.set(1);
    flags.set(2);
}
int main()
{
    /////////////////////////////////////////////////////////
    // the following must always present in main files
    nrf52_disable_approtect();
    ///////////////////////////////////////////////////////////

    /*---------------------------------------------------------*/
    // Start your implementation below
    button_interrupt.rise(&button_isr);
    button_interrupt.fall(&button_isr);
    // 1. create two threads with different priorities. 
    // the threads are created in suspended state
    

    // 2. start the threads, and assign their procedures (functions)
    task1.start(task1_proc);
    task2.start(task2_proc);
    
    // 3. wait for threads to terminate (if they ever terminate)
    while(true) {
        ThisThread::sleep_for(BLINKING_RATE);
    }

    // the following code is just a placeholder. You may remove it if you find it fit.
    //---------------BEGIN PLACE HOLDER-------------------------/

    //---------------END PLACE HOLDER-------------------------/
    
   return 1;
}