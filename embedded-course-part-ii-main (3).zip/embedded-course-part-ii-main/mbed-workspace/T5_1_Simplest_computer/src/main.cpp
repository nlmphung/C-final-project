/* mbed Microcontroller Library
 * Copyright (c) 2019 ARM Limited
 * SPDX-License-Identifier: Apache-2.0
 */

#include "mbed.h"
#include "nrf52832_app_protect.h"

// Blinking rate in milliseconds
#define BLINKING_RATE     500ms


int main()
{
    /////////////////////////////////////////////////////////
    // the following must always present in main files
    nrf52_disable_approtect();
    ///////////////////////////////////////////////////////////
    /*---------------------------------------------------------*/
    // Start your implementation below
    // 1. Initialise the digital pin LED1 as an output
    DigitalOut led(LED1);
    // 2. declare the IO, and configure button GPIO
    DigitalIn button(BUTTON1);
    // 3. Turn the LED OFF
    //led.write(1);
    // The LED is directly connected to IO: VCC -- LED -- GPIO. The current flows through 
    // LED when the GPIO is LOW. We turn it off by setting GPIO to high. 
    
    while (true) {
        // 4. Check the button state and change the LED state accordingly.
        led.write(button.read());
        // the following is just a placeholder. You may remove it if you find it fit.
        //---------------BEGIN PLACE HOLDER-------------------------/
        ThisThread::sleep_for(BLINKING_RATE);
        //---------------END PLACE HOLDER-------------------------/
    }
    return 1;
}