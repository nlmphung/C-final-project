/* mbed Microcontroller Library
 * Copyright (c) 2019 ARM Limited
 * SPDX-License-Identifier: Apache-2.0
 */

#include "mbed.h"
#include <stdio.h>
#include <iostream>
#include <string>
#include "nrf52832_app_protect.h"

// Blinking rate in milliseconds
#define BLINKING_RATE     500ms

// declare the IO, and configure GPIO
EventQueue q;
// Define the Button Edge triggered GPIO interrupt function
DigitalIn button(BUTTON1);
DigitalOut led(LED1);

InterruptIn interrupt(BUTTON1, PullUp);

BufferedSerial serial_port(STDIO_UART_TX, STDIO_UART_RX, 115200);

void print_msg(const std::string &msg) {
    serial_port.write(msg.c_str(), msg.size());
}

void button_isr(void) {
    led.write(!led);
    q.call(print_msg, led ? "HIGH\n" : "LOW\n");
}

int main()
{
    /////////////////////////////////////////////////////////
    // the following must always present in main files
    nrf52_disable_approtect();
    ///////////////////////////////////////////////////////////
    /*---------------------------------------------------------*/
    // Start your implementation below
    // 1. Initialise the digital pin LED1 as an output
    serial_port.set_blocking(false);
    // 2. Turn the LED OFF
    led.write(1);
    // The LED is directly connected to IO: VCC -- LED -- GPIO. The current flows
    // through LED when the GPIO is LOW. Thus, we turn it off by setting GPIO to high.
    // 3. configure the button interrupts for rising and falling edges
    interrupt.rise(&button_isr);
    interrupt.fall(&button_isr);

    // function must not return. So, you can put it into sleep. 
    q.call(print_msg, "Hello, nRF52-DK!\n");
    // the following code is just a placeholder. You may remove it if you find it fit.
    //---------------BEGIN PLACE HOLDER-------------------------/
    while (true) {
        q.dispatch_once();
        ThisThread::sleep_for(BLINKING_RATE);
    }
    //---------------BEGIN PLACE HOLDER-------------------------/
    
    return 1;
}